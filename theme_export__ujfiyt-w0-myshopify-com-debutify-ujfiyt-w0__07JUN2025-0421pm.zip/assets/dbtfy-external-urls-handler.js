document.addEventListener('DOMContentLoaded', () => {
  if (Debutify.widgets['external-urls-handler']['auto_scan'] == true) {
    let externalUrls = document.querySelectorAll('a[href^="http"]:not([href*="' + window.location.hostname + '"])');
    externalUrls.forEach((url) => {
      url.setAttribute('target', '_blank');
      url.setAttribute('rel', 'noopener');
    });
  } else {
    if (!Debutify.widgets['external-urls-handler']['external_urls']) return;
    const external_urls = Debutify.widgets['external-urls-handler']['external_urls'].split(',');

    if (external_urls.length > 0) {
      external_urls.forEach((url) => {
        url = url.trim();
        let externalUrls = document.querySelectorAll('a[href*="' + url + '"]');
        externalUrls.forEach((url) => {
          url.setAttribute('target', '_blank');
          url.setAttribute('rel', 'noopener');
        });
      });
    }
  }
});
